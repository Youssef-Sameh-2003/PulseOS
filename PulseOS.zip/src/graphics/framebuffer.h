#ifndef FRAMEBUFFER_H
#define FRAMEBUFFER_H

#include <stdint.h>

typedef struct {
    uint32_t width;
    uint32_t height;
    uint32_t pitch;
    uint32_t bpp;
    uint8_t *address;
} framebuffer_t;

int framebuffer_init(uint32_t mb2_addr, framebuffer_t *fb);


#endif