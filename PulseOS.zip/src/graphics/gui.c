#include "gui.h"

// Temporary: hardcoded framebuffer info (adjust as needed)
static framebuffer_t fb = {
    .width = 800,
    .height = 600,
    .pitch = 800 * 4,
    .bpp = 32,
    .address = (uint8_t*)0xE0000000 // Change to your framebuffer address!
};

static mouse_t mouse = {400, 300, 0};

static uint32_t rgb(uint8_t r, uint8_t g, uint8_t b) {
    return (b << 16) | (g << 8) | r;
}

// Draw a pixel
static void fb_putpixel(framebuffer_t *fb, int x, int y, uint32_t color) {
    if (x < 0 || y < 0 || x >= (int)fb->width || y >= (int)fb->height) return;
    uint32_t *pixel = (uint32_t *)(fb->address + y * fb->pitch + x * 4);
    *pixel = color;
}

// Fill screen
static void fb_clear(framebuffer_t *fb, uint32_t color) {
    for (uint32_t y = 0; y < fb->height; y++)
        for (uint32_t x = 0; x < fb->width; x++)
            fb_putpixel(fb, x, y, color);
}

// Draw a rectangle
static void fb_rect(framebuffer_t *fb, int x, int y, int w, int h, uint32_t color) {
    for (int iy = 0; iy < h; iy++)
        for (int ix = 0; ix < w; ix++)
            fb_putpixel(fb, x + ix, y + iy, color);
}

// Draw mouse cursor (simple crosshair)
static void draw_mouse_cursor(framebuffer_t *fb, mouse_t *mouse) {
    for (int dx = -8; dx <= 8; dx++)
        fb_putpixel(fb, mouse->x + dx, mouse->y, rgb(255, 0, 0));
    for (int dy = -8; dy <= 8; dy++)
        fb_putpixel(fb, mouse->x, mouse->y + dy, rgb(255, 0, 0));
}

// --- PS/2 Mouse Support (polling, minimal) ---
// You need to implement ps2_mouse_init and ps2_mouse_poll for your platform.

extern void ps2_mouse_init();
extern int ps2_mouse_poll(int *dx, int *dy, int *buttons);

// --- Main GUI Loop ---
void gui_main(framebuffer_t *fb) {
    ps2_mouse_init();
    fb_clear(&fb, rgb(40, 40, 40));
    int running = 1;
    while (running) {
        // Poll mouse
        int dx = 0, dy = 0, btns = 0;
        if (ps2_mouse_poll(&dx, &dy, &btns)) {
            mouse.x += dx;
            mouse.y += dy;
            if (mouse.x < 0) mouse.x = 0;
            if (mouse.y < 0) mouse.y = 0;
            if (mouse.x >= (int)fb->width) mouse.x = fb->width - 1;
            if (mouse.y >= (int)fb->height) mouse.y = fb->height - 1;
            mouse.buttons = btns;
        }

        // Redraw screen
        fb_clear(&fb, rgb(40, 40, 40));
        // Draw demo window
        fb_rect(&fb, 120, 100, 400, 300, rgb(220,220,255));
        fb_rect(&fb, 120, 100, 400, 24, rgb(64,64,128)); // title bar
        // Draw mouse
        draw_mouse_cursor(&fb, &mouse);

        // Simple button (demo)
        fb_rect(&fb, 180, 320, 120, 40, rgb(180,255,180));
        // Button click detection
        if (mouse.x > 180 && mouse.x < 300 && mouse.y > 320 && mouse.y < 360 && (mouse.buttons & 1)) {
            fb_rect(&fb, 180, 320, 120, 40, rgb(255,100,100));
            // For real GUI, add text rendering and event queue
        }

        // Simple delay
        for (volatile int i = 0; i < 100000; i++);
    }
}