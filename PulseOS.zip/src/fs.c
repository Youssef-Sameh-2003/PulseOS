#include "fs.h"

FS_File fs_files[FS_MAX_FILES];

// Simple implementations for kernel use
size_t strlen(const char *s) {
    size_t len = 0;
    while (s[len]) len++;
    return len;
}

void *memcpy(void *dest, const void *src, size_t n) {
    char *d = (char *)dest;
    const char *s = (const char *)src;
    for (size_t i = 0; i < n; i++)
        d[i] = s[i];
    return dest;
}

char *strcpy(char *dest, const char *src) {
    char *d = dest;
    while ((*d++ = *src++));
    return dest;
}

char *strncpy(char *dest, const char *src, size_t n) {
    size_t i;
    for (i = 0; i < n && src[i]; i++)
        dest[i] = src[i];
    for (; i < n; i++)
        dest[i] = 0;
    return dest;
}

int fs_create(const char* name) {
    for (int i = 0; i < FS_MAX_FILES; i++) {
        if (!fs_files[i].used) {
            strncpy(fs_files[i].name, name, FS_MAX_FILENAME-1);
            fs_files[i].name[FS_MAX_FILENAME-1] = 0;
            fs_files[i].size = 0;
            fs_files[i].used = 1;
            return 0;
        }
    }
    return -1;
}

int fs_write(const char* name, const char* data, size_t len) {
    for (int i = 0; i < FS_MAX_FILES; i++) {
        if (fs_files[i].used && strcmp(fs_files[i].name, name) == 0) {
            size_t to_write = len > FS_MAX_FILESIZE ? FS_MAX_FILESIZE : len;
            memcpy(fs_files[i].data, data, to_write);
            fs_files[i].size = to_write;
            return 0;
        }
    }
    return -1;
}

int fs_read(const char* name, char* out, size_t maxlen) {
    for (int i = 0; i < FS_MAX_FILES; i++) {
        if (fs_files[i].used && strcmp(fs_files[i].name, name) == 0) {
            size_t to_read = fs_files[i].size > maxlen ? maxlen : fs_files[i].size;
            memcpy(out, fs_files[i].data, to_read);
            return to_read;
        }
    }
    return -1;
}

int fs_list(char* out, size_t maxlen) {
    size_t total = 0;
    for (int i = 0; i < FS_MAX_FILES; i++) {
        if (fs_files[i].used) {
            size_t len = strlen(fs_files[i].name);
            if (total + len + 2 < maxlen) {
                strcpy(out + total, fs_files[i].name);
                total += len;
                out[total++] = '\n';
            }
        }
    }
    out[total] = 0;
    return total;
}