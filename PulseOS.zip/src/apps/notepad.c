#include <stddef.h>
#include <stdint.h>
#include "notepad.h"
#include "../fs.h"

#define NP_LINES 20
#define NP_LINE_LEN 60
static char lines[NP_LINES][NP_LINE_LEN];
static size_t line_lens[NP_LINES];
static size_t cur_line = 0, cur_col = 0;

extern const char kbdus[128];
extern const char kbdus_shift[128];
extern volatile int shift_pressed;
extern uint8_t inb(uint16_t port);

static void np_draw(void (*terminal_clear)(), void (*terminal_write)(const char*)) {
    terminal_clear();
    terminal_write("PulseOS Notepad (ESC=exit, F2=save)\n");
    for (size_t i = 0; i <= cur_line; i++) {
        for (size_t j = 0; j < line_lens[i]; j++) {
            char out[2] = {lines[i][j], '\0'};
            terminal_write(out);
        }
        terminal_write("\n");
    }
    terminal_write("> ");
}

static void np_save(void (*terminal_write)(const char*)) {
    // Prompt for filename
    char filename[FS_MAX_FILENAME] = {0};
    terminal_write("\nEnter filename to save: ");
    size_t fn_len = 0;
    int getting_name = 1;
    while (getting_name) {
        if (inb(0x64) & 0x01) {
            uint8_t sc = inb(0x60);

            if (sc == 0x2A || sc == 0x36) { shift_pressed = 1; continue; }
            if (sc == 0xAA || sc == 0xB6) { shift_pressed = 0; continue; }
            if (!(sc & 0x80)) {
                char c = shift_pressed ? kbdus_shift[sc] : kbdus[sc];
                if (c == '\n' && fn_len > 0) {
                    filename[fn_len] = 0;
                    getting_name = 0;
                } else if (c == '\b' && fn_len > 0) {
                    fn_len--;
                    terminal_write("\b \b");
                } else if (c && fn_len < FS_MAX_FILENAME - 1) {
                    filename[fn_len++] = c;
                    char out[2] = {c, '\0'};
                    terminal_write(out);
                }
            }
        }
        for (volatile int i = 0; i < 50000; i++);
    }

    // Build text buffer
    char fulltext[FS_MAX_FILESIZE];
    size_t idx = 0;
    for (size_t i = 0; i <= cur_line; i++) {
        for (size_t j = 0; j < line_lens[i]; j++) {
            if (idx < FS_MAX_FILESIZE-1)
                fulltext[idx++] = lines[i][j];
        }
        if (idx < FS_MAX_FILESIZE-1)
            fulltext[idx++] = '\n';
    }
    fulltext[idx] = 0;
    fs_create(filename); // Create if not exists
    fs_write(filename, fulltext, idx);
    terminal_write("\nSaved to ");
    terminal_write(filename);
    terminal_write("\n");
}

static void np_load(const char* filename, void (*terminal_write)(const char*)) {
    char filetext[FS_MAX_FILESIZE];
    int n = fs_read(filename, filetext, sizeof(filetext));
    if (n <= 0) {
        terminal_write("\nFile not found or empty.\n");
        return;
    }

    // Clear lines
    for (size_t i = 0; i < NP_LINES; i++) line_lens[i] = 0;
    cur_line = cur_col = 0;

    // Load content into lines
    size_t idx = 0;
    while (idx < (size_t)n && cur_line < NP_LINES) {
        if (filetext[idx] == '\n') {
            cur_line++;
            cur_col = 0;
            idx++;
        } else if (cur_col < NP_LINE_LEN-1) {
            lines[cur_line][cur_col++] = filetext[idx++];
            line_lens[cur_line] = cur_col;
        } else {
            idx++; // skip if line too long
        }
    }
}

void notepad_app(void (*terminal_clear)(), void (*terminal_write)(const char*), int read_mode, const char* read_filename) {
    for (size_t i = 0; i < NP_LINES; i++) line_lens[i] = 0;
    cur_line = 0; cur_col = 0;
    if (read_mode && read_filename && read_filename[0])
        np_load(read_filename, terminal_write);
    np_draw(terminal_clear, terminal_write);

    int running = 1;
    while (running) {
        if (inb(0x64) & 0x01) {
            uint8_t sc = inb(0x60);

            // Shift key logic
            if (sc == 0x2A || sc == 0x36) { shift_pressed = 1; continue; }
            if (sc == 0xAA || sc == 0xB6) { shift_pressed = 0; continue; }

            // F2 is scan code 0x3C
            if (sc == 0x3C && !(sc & 0x80)) {
                np_save(terminal_write);
                np_draw(terminal_clear, terminal_write);
                continue;
            }

            if (!(sc & 0x80)) { // key press
                char c = shift_pressed ? kbdus_shift[sc] : kbdus[sc];
                if (c == 27) { // ESC
                    running = 0;
                    continue;
                }
                if (c == '\n') {
                    if (cur_line < NP_LINES-1) {
                        cur_line++;
                        cur_col = 0;
                    }
                    np_draw(terminal_clear, terminal_write);
                } else if (c == '\b' && cur_col > 0) {
                    cur_col--;
                    line_lens[cur_line]--;
                    np_draw(terminal_clear, terminal_write);
                } else if (c && cur_col < NP_LINE_LEN-1) {
                    lines[cur_line][cur_col++] = c;
                    line_lens[cur_line] = cur_col;
                    char out[2] = {c, '\0'};
                    terminal_write(out);
                }
            }
        }
        for (volatile int i = 0; i < 50000; i++);
    }
    terminal_clear();
    terminal_write("Exiting Notepad.\n");
}