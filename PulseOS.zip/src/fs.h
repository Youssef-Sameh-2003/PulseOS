#ifndef FS_H
#define FS_H

#include <stddef.h>

#define FS_MAX_FILES 16
#define FS_MAX_FILENAME 16
#define FS_MAX_FILESIZE 1024

typedef struct {
    char name[FS_MAX_FILENAME];
    char data[FS_MAX_FILESIZE];
    size_t size;
    int used;
} FS_File;

int fs_create(const char* name);
int fs_write(const char* name, const char* data, size_t len);
int fs_read(const char* name, char* out, size_t maxlen);
int fs_list(char* out, size_t maxlen);

#endif